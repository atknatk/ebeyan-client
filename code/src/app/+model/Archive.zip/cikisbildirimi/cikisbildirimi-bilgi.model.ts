import { DnXmlElement, DnXmlModel, DnXmlRoot } from '../../shared/utils/dn-serialize';
import { FirmaModel } from '../enum/firma.model';
import { isNullOrUndefined } from 'util';
import { CikisbildirimiTasimaSenetModel } from './cikisbildirimi-tasimasenet.model';
import { CikisbildirimiTasitinUgradigiUlke } from './cikisbildirimi-tasitin-ugradigi-ulke';
import {ModelBase} from "../model";

export class CikisbildirimiBilgiModel extends ModelBase{


  @DnXmlElement('RefNo')
  refNo: string;

  @DnXmlElement('BeyanTuru')
  beyanTuru: string;

  @DnXmlElement('Rejim')
  rejim: string;

  @DnXmlElement('TasimaSekli')
  tasimaSekli: string;

  @DnXmlElement('GumrukIdaresi')
  gumrukIdaresi: string;

  @DnXmlElement('EkBelgeSayisi')
  ekBelgeSayisi: number;

  @DnXmlElement('KullaniciKodu')
  kullaniciKodu: string;

  @DnXmlModel('vergiNo', 'BeyanSahibiVergiNo')
  beyanSahibi: FirmaModel;

  @DnXmlElement('TasiyiciVergiNo')
  tasiyiciFirmaVergiNo: string;

  @DnXmlElement('TasitinAdi')
  tasitAdi: string;

  @DnXmlElement('PlakaSeferNo')
  tasitNumarasi: string;

  @DnXmlElement('ReferansNumarasi')
  tasitReferansNumarasi: string;

  @DnXmlElement('UlkeKodu')
  tasitUlkesi: string;

  @DnXmlElement('VarisTarihSaati')
  tasitVarisTarihTescil: Date;

  @DnXmlElement('OncekiBeyanNo')
  oncekiBeyanNo: string;

  @DnXmlElement('GrupTasimaSenediNo')
  grupTasimaSenediNo: string;

  @DnXmlElement('VarisCikisGumrukIdaresi')
  ilkVarisYeri: string;

  @DnXmlElement('TirAtaKarneNo')
  tirKarneNo: string;

  @DnXmlElement('Kurye')
  isKurye: boolean;

  @DnXmlElement('DorseNo1')
  tasitDorseNo1: string;

  @DnXmlElement('DorseNo1Uyrugu')
  tasitDorse1Uyruk: string;

  @DnXmlElement('DorseNo2')
  tasitDorseNo2: string;

  @DnXmlElement('DorseNo2Uyrugu')
  tasitDorse2Uyruk: string;

  @DnXmlElement('Diger')
  diger: string;

  @DnXmlElement('XmlRefId')
  xmlRefId: string;

  @DnXmlElement('UlkeKoduYuk')
  yuklemeUlkesi: string;

  @DnXmlElement('LimanYerAdiYuk')
  yuklemeLimani: string;

  @DnXmlElement('UlkeKoduBos')
  bosaltmaUlkesi: string;

  @DnXmlElement('LimanYerAdiBos')
  bosaltmaLimani: string;

  @DnXmlElement('YuklemeBosaltmaYeri')
  yuklemeBosaltmaYeri: string;

  @DnXmlElement('TasiyiciFirma')
  tasiyiciFirma: FirmaModel;

  @DnXmlElement('EmniyetGuvenlik')
  isEmniyetGuvenlik: boolean;

  @DnXmlElement('TasitinUgradigiUlkeler')
  @DnXmlRoot('TasitinUgradigiUlkeBilgisi')
  cikisBildirimiTasitinUgradigiUlkelerList: CikisbildirimiTasitinUgradigiUlke[];

  @DnXmlElement('TasimaSenetleri')
  @DnXmlRoot('TasimaSenediBilgisi')
  cikisBildirimiTasimaSenetList: CikisbildirimiTasimaSenetModel[];


  constructor(options: {} = {}) {
    super();
    this.equalizer(options);
    this.beyanSahibi = isNullOrUndefined(options['beyanSahibi']) ? undefined : new FirmaModel(options['beyanSahibi']);

    if (!isNullOrUndefined(options['tasiyiciFirma'])) {
      if (isNullOrUndefined(options['tasiyiciFirma']['vergiNo'])) {
        this.tasiyiciFirma = isNullOrUndefined(options['tasiyiciFirma']) ? undefined : new FirmaModel(options['tasiyiciFirma']);
      } else {
        this.tasiyiciFirmaVergiNo = options['tasiyiciFirma']['vergiNo'];
      }
    }


    if (options['cikisBildirimiTasimaSenetList']) {
      this.cikisBildirimiTasimaSenetList = Array<CikisbildirimiTasimaSenetModel>();
      options['cikisBildirimiTasimaSenetList'].forEach(senet => {
        this.cikisBildirimiTasimaSenetList.push(new CikisbildirimiTasimaSenetModel(senet));
      });
    }
    if (options['cikisBildirimiTasitinUgradigiUlkelerList']) {
      this.cikisBildirimiTasitinUgradigiUlkelerList = Array<CikisbildirimiTasitinUgradigiUlke>();
      options['cikisBildirimiTasitinUgradigiUlkelerList'].forEach(senet => {
        this.cikisBildirimiTasitinUgradigiUlkelerList.push(new CikisbildirimiTasitinUgradigiUlke(senet));
      });
    }
  }


}

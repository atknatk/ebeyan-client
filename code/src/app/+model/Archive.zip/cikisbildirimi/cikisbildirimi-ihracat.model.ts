import {DnXmlElement} from '../../shared/utils/dn-serialize';

export class CikisbildirimiIhracatModel {


  @DnXmlElement('BrutAgirlik')
  brutAgirlik: number;

  @DnXmlElement('KapAdedi')
  kapAdet: number;

  @DnXmlElement('Numarasi')
  numarasi: string;

  @DnXmlElement('ParcaliMi')
  isParcali: boolean;

  @DnXmlElement('Tipi')
  ihracatIlgiliBeyanTip: string;


  constructor(options: {}
                = {}) {
    this.brutAgirlik = options['brutAgirlik'];
    this.kapAdet = options['kapAdet'];
    this.numarasi = options['numarasi'];
    this.isParcali = options['isParcali'];
    this.ihracatIlgiliBeyanTip = options['ihracatIlgiliBeyanTip'];
  }
}

import {DnXmlElement} from '../../shared/utils/dn-serialize';
import {ModelBase} from "../model";

export class CikisbildirimiTasimaSatirModel extends ModelBase {

  @DnXmlElement('BrutAgirlik')// BrutAgirlik
  brutAgirlik: number;

  @DnXmlElement('KapAdedi')// KapAdedi
  kapAdet: number;

  @DnXmlElement('KapCinsi') // KapCinsi
  kapKod: string;

  @DnXmlElement('KonteynerTipi')// KontynerTipi
  konteynerTip: string;

  @DnXmlElement('MarkaNo')// MarkaNo
  markaNo: string;

  @DnXmlElement('MuhurNumarasi')// MuhurNumarasi
  muhurNo: string;

  @DnXmlElement('NetAgirlik')// NetAgirlik
  netAgirlik: number;

  @DnXmlElement('OlcuBirimi')// OlcuBirimi
  olcuBirim: string;

  @DnXmlElement('SatirNo')// SatirNo
  satirNo: number;


  constructor(options: {}
                = {}) {
    super();
    this.equalizer(options)
  }
}

import { DnXmlElement, DnXmlModel } from '../../shared/utils/dn-serialize';
import { SimpleDetaylibeyanKalemModel } from '../simple/simple-detaylibeyan-kalem.model';
import { isNullOrUndefined } from '@dinazor/core';
import { IstenenDokumanModel } from '../enum/istenen-dokuman.model';
import { YesNoModel } from '../enum/yes-no.model';

/**
 * Created by cabbar on 23.05.2017.
 */
export class DetayliBeyanDokumanModel {


  @DnXmlModel('kalemNo', 'Kalem_no')
  simpleDetayliBeyanKalem: SimpleDetaylibeyanKalemModel;

  @DnXmlElement('Kod')
  istenenDokuman: string;

  @DnXmlModel('otherNameVY', 'Dogrulama')
  dogrulama: YesNoModel;

  @DnXmlElement('Belge_tarihi')
  belgeTarihi: string;

  @DnXmlElement('Referans')
  referans: string;

  @DnXmlElement('Vize_Tarihi')
  vizeTarihi: string;


  constructor(options: {} = {}) {
    this.simpleDetayliBeyanKalem = isNullOrUndefined(options['simpleDetayliBeyanKalem']) ? undefined : new SimpleDetaylibeyanKalemModel(options['simpleDetayliBeyanKalem']);
    this.istenenDokuman = options['istenenDokuman'];
    this.dogrulama = isNullOrUndefined(options['dogrulama']) ? undefined : new YesNoModel(options['dogrulama']);
    this.belgeTarihi = options['belgeTarihi'];
    this.referans = options['referans'];
    this.vizeTarihi = options['vizeTarihi'];
  }
}

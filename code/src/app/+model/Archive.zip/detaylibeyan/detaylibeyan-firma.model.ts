import {UlkeModel} from '../enum/ulke.model';
import {isNullOrUndefined} from '@dinazor/core';
import {DnXmlElement, DnXmlIgnore, DnXmlModel} from '../../shared/utils/dn-serialize';
import {ModelBase} from "../model";

export class DetayliBeyanFirmaModel extends ModelBase {

  @DnXmlIgnore()
  id: number;

  @DnXmlElement('Adi_unvani')
  adiUnvani: string;

  // @DnXmlElement('Kimlik_turu')
  // Kimlik_turu: string;

  // @DnXmlElement('No')
  // No: string;

  @DnXmlIgnore()
  vergiNo: string;

  @DnXmlElement('Cadde_s_no')
  cadSNo: string;

  @DnXmlElement('Il_ilce')
  ilIlce: string;

  @DnXmlElement('Posta_kodu')
  postaKodu: string;

  @DnXmlElement('Ulke_kodu')
  ulkeKod: string;

  @DnXmlElement('Faks')
  fax: string;

  @DnXmlElement('Telefon')
  tel: string;

  @DnXmlElement('Tip')
  tip: string;


  constructor(options: {} = {}) {
    super();
    this.equalizer(options);
  }
}

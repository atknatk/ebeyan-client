import {isNullOrUndefined} from '@dinazor/core';
import {HavacilikYakitTuruModel} from 'app/+model/detaylibeyan/havacilik-yakit-turu.model';
import {DnXmlElement, DnXmlModel, DnXmlRoot} from '../../shared/utils/dn-serialize';
import {ModelBase} from "../model";
import {YesNoModel} from "../enum/yes-no.model";
import {DetayliBeyanFirmaModel} from "./detaylibeyan-firma.model";
import {OdemeSekliModel} from "../enum/odemesekli.model";
import {DetayliBeyanTamamlayiciModel} from "./detaylibeyan-tamamlayici.model";
import {TcgbAcmaKapatmaModel} from "./tcgb-acma-kapatma.model";
import {DetayliBeyanMarkaModel} from "./detaylibeyan-marka.model";
import {DetayliBeyanKonteynerModel} from "./detaylibeyan-konteyner.model";
import {DetayliBeyanBilgiModel} from "./detaylibeyan-bilgi.model";

/**
 * Created by cabbar on 23.05.2017.
 */
export class DetayliBeyanKalemModel extends ModelBase {

  // region Properties

  // @DnXmlElement('Gtip')
  @DnXmlElement('Gtip')
  gtip: string;

  @DnXmlModel('name', 'Imalatci_firma_bilgisi')
  isImalatciFirma: YesNoModel;

  @DnXmlModel('vergiNo', 'Imalatci_Vergino')
  imalatciFirma: DetayliBeyanFirmaModel;

  @DnXmlElement('Kalem_sira_no')
  kalemNo: number;

  @DnXmlElement('Mensei_ulke')
  menseUlke: string;

  @DnXmlElement('Brut_agirlik')
  brutAgirlik: number;

  @DnXmlElement('Net_agirlik')
  netAgirlik: number;

  @DnXmlElement('Tamamlayici_olcu_birimi')
  tamamlayiciOlcuBirim: string;

  @DnXmlElement('Istatistiki_miktar')
  istatistikiMiktar: number;

  @DnXmlElement('Miktar_birimi')
  miktarBirim: string;

  @DnXmlElement('Uluslararasi_anlasma')
  uluslararasiAnlasmalar: string;

  @DnXmlElement('Algilama_birimi_1')
  algilamaBirimi1: string;

  @DnXmlElement('Algilama_miktari_1')
  algilamaMiktari1: number;

  @DnXmlElement('Algilama_birimi_2')
  algilamaBirimi2: string;

  @DnXmlElement('Algilama_miktari_2')
  algilamaMiktari2: number;

  @DnXmlElement('Algilama_birimi_3')
  algilamaBirimi3: string;

  @DnXmlElement('Algilama_miktari_3')
  algilamaMiktari3: number;

  @DnXmlElement('Muafiyetler_1')
  muafiyetKod1: string;

  @DnXmlElement('Muafiyetler_2')
  muafiyetKod2: string;

  @DnXmlElement('Muafiyetler_3')
  muafiyetKod3: string;

  @DnXmlElement('Muafiyetler_4')
  muafiyetKod4: string;

  @DnXmlElement('Muafiyetler_5')
  muafiyetKod5: string;

  @DnXmlElement('Teslim_sekli')
  teslimSekli: string;

  @DnXmlElement('Ek_kod')
  ekKod: string;

  @DnXmlElement('Ozellik')
  ozellik: string;

  @DnXmlElement('Fatura_miktari')
  fatura: number;

  @DnXmlElement('Fatura_miktarinin_dovizi')
  faturaDoviz: string;

  @DnXmlElement('Sinir_gecis_ucreti')
  sinirGecisUcreti: number;

  @DnXmlElement('Navlun_miktari')
  navlunBedeli: number;

  @DnXmlElement('Navlun_miktarinin_dovizi')
  navlunBedeliDoviz: string;

  @DnXmlElement('Istatistiki_kiymet')
  istatiskiKiymet: string;

  // TODO @DnXmlElement( '')
  // istatiskiKiymetDoviz: DovizModel;

  @DnXmlElement('Sigorta_miktari')
  sigortaBedeli: number;

  @DnXmlElement('Sigorta_miktarinin_dovizi')
  sigortaBedeliDoviz: string;

  @DnXmlElement('Tarifedeki_tanimi')
  tarifedekiTanimi: string;

  @DnXmlElement('Ticari_tanimi')
  ticariTanimi: string;

  @DnXmlElement('Marka')
  esyaMarka: string;

  @DnXmlElement('Numara')
  esyaNumara: number;

  @DnXmlElement('Adedi')
  esyaAdet: number;

  @DnXmlElement('Cinsi')
  esyaCinsi: string;


  @DnXmlModel('name', 'Mahrece_iade')
  mahreceIade: YesNoModel;

  @DnXmlModel('name', 'Ikincil_islem')
  isIkincilIslem: YesNoModel;

  @DnXmlElement('Satir_no')
  satirNo: string;

  @DnXmlElement('Miktar')
  miktar: number;

  @DnXmlElement('Kdv_orani')
  kdv: string;

  @DnXmlElement('Kullanilmis_esya')
  kullanilmisEsya: string;

  @DnXmlElement('Aciklama_44')
  aciklamalar: string;

  @DnXmlElement('Yurtici_Diger')
  yurticiDiger: number;

  @DnXmlElement('Yurtici_Banka')
  yurticiBankaMasraflari: number;

  @DnXmlElement('Yurtici_Depolama')
  yurticiDepolamaGiderleri: number;

  @DnXmlElement('Yurtici_Tahliye')
  yurticiTahmilTahliyeGider: number;

  @DnXmlElement('Yurtici_Liman')
  yurticiLimanGiderleri: number;

  @DnXmlElement('Yurtici_Kultur')
  yurticiKulturBakanligiKesinti: number;

  @DnXmlElement('Yurtici_Kkdf')
  yurticiKkdf: number;

  @DnXmlElement('Yurtici_Cevre')
  yurticiCevreKatkiPayi: number;

  @DnXmlElement('Yurtici_Diger_Aciklama')
  yurticiDigerAciklama: string;

  @DnXmlElement('Muafiyet_Aciklamasi')
  muafiyetAciklama: string;

  @DnXmlElement('Referans_Tarihi')
  referansTarihi: string;

  @DnXmlElement('YurtDisi_Komisyon')
  yurtdisiKomisyon: number;

  @DnXmlElement('YurtDisi_Demuraj')
  yurtdisiDemuraj: number;

  @DnXmlElement('YurtDisi_Royalti')
  yurtdisiRoyalti: number;

  @DnXmlElement('YurtDisi_Faiz')
  yurtdisiFaiz: number;

  @DnXmlElement('YurtDisi_Diger')
  yurtdisiDiger: number;

  @DnXmlElement('YurtDisi_Komisyon_Dovizi')
  yurtdisiKomisyonDoviz: string;

  @DnXmlElement('YurtDisi_Demuraj_Dovizi')
  yurtdisiDemurajDoviz: string;

  @DnXmlElement('YurtDisi_Royalti_Dovizi')
  yurtdisiRoyaltiDoviz: string;

  @DnXmlElement('YurtDisi_Faiz_Dovizi')
  yurtdisiFaizDoviz: string;

  @DnXmlElement('YurtDisi_Diger_Dovizi')
  yurtdisiDigerDoviz: string;

  @DnXmlElement('YurtDisi_Diger_Aciklama')
  digerAciklama: string;

  @DnXmlElement('Kalem_Islem_Niteligi')
  isleminNiteligi: string;

  @DnXmlElement('Giris_Cikis_Amaci')
  esyaninGirisCikisAmaci: string;

  @DnXmlElement('Giris_Cikis_Amaci_Aciklama')
  esyaninGirisCikisAmaciAciklama: string;

  @DnXmlElement('STM_IlKodu')
  stmBagliIl: string;

  @DnXmlModel('id', 'OdemeSekli')
  odemeSekil: OdemeSekliModel;
  // endregion


  @DnXmlElement('tamamlayici_bilgi')
  @DnXmlRoot('tamamlayici')
  detayliBeyanTamamlayiciList: DetayliBeyanTamamlayiciModel[];

  @DnXmlElement('tcgbacmakapatma_bilgi')
  @DnXmlRoot('tcgbacmakapatma')
  tcgbAcmaKapatmaList: TcgbAcmaKapatmaModel[];

  @DnXmlElement('marka_model_bilgi')
  @DnXmlRoot('Marka')
  detayliBeyanMarkaList: DetayliBeyanMarkaModel[];

  @DnXmlElement('konteyner_Bilgi')
  @DnXmlRoot('Konteyner')
  detayliBeyanKonteynerList: DetayliBeyanKonteynerModel[];

  // VergiMuafiyetleri

  @DnXmlElement('HavacilikYakitTurleri')
  @DnXmlRoot('HavacilikYakitTuru')
  havacilikYakitTuruList: HavacilikYakitTuruModel[];

  constructor(options: {} = {}, anaBeyanname: DetayliBeyanBilgiModel) {
    super();
    this.equalizer(options);
    this.isImalatciFirma = isNullOrUndefined(options['isImalatciFirma']) ? undefined : new YesNoModel(options['isImalatciFirma']);
    this.imalatciFirma = isNullOrUndefined(options['imalatciFirma']) ? undefined : new DetayliBeyanFirmaModel(options['imalatciFirma']);

    if (anaBeyanname.rejimKod) {
      const rejimCode = anaBeyanname.rejimKod;
      if (rejimCode.indexOf('4') == 0 || rejimCode.indexOf('5') == 0 || rejimCode.indexOf('6') == 0 ||
        rejimCode.indexOf('7') == 0 || rejimCode.indexOf('9') == 0) {
        this.istatiskiKiymet = '0';
        this.teslimSekli = undefined;
      } else {
        this.istatiskiKiymet = options['istatiskiKiymet'];
        this.teslimSekli = options['teslimSekli'];
      }
    }
      this.mahreceIade = isNullOrUndefined(options['mahreceIade']) ? undefined : new YesNoModel(options['mahreceIade']);
    this.isIkincilIslem = isNullOrUndefined(options['isIkincilIslem']) ? undefined : new YesNoModel(options['isIkincilIslem']);
    this.odemeSekil = isNullOrUndefined(options['odemeSekil']) ? undefined : new OdemeSekliModel(options['odemeSekil']);
// TODO enum
    this.stmBagliIl = options['stmBagliIl'];
    // endregion

    if (options['detayliBeyanTamamlayiciList']) {
      this.detayliBeyanTamamlayiciList = Array<DetayliBeyanTamamlayiciModel>();
      options['detayliBeyanTamamlayiciList'].forEach(tamamlayici => {
        this.detayliBeyanTamamlayiciList.push(new DetayliBeyanTamamlayiciModel(tamamlayici));
      });
    }

    if (options['tcgbAcmaKapatmaList']) {
      this.tcgbAcmaKapatmaList = Array<TcgbAcmaKapatmaModel>();
      options['tcgbAcmaKapatmaList'].forEach(acma => {
        this.tcgbAcmaKapatmaList.push(new TcgbAcmaKapatmaModel(acma));
      });
    }

    if (options['detayliBeyanMarkaList']) {
      this.detayliBeyanMarkaList = Array<DetayliBeyanMarkaModel>();
      options['detayliBeyanMarkaList'].forEach(marka => {
        this.detayliBeyanMarkaList.push(new DetayliBeyanMarkaModel(marka));
      });
    }

    if (options['detayliBeyanKonteynerList']) {
      this.detayliBeyanKonteynerList = Array<DetayliBeyanKonteynerModel>();
      options['detayliBeyanKonteynerList'].forEach(konteyner => {
        this.detayliBeyanKonteynerList.push(new DetayliBeyanKonteynerModel(konteyner));
      });
    }

    // VergiMuafiyetleri

    if (options['havacilikYakitTuruList']) {
      this.havacilikYakitTuruList = Array<HavacilikYakitTuruModel>();
      options['havacilikYakitTuruList'].forEach(havacilik => {
        this.havacilikYakitTuruList.push(new HavacilikYakitTuruModel(havacilik));
      });
    }


  }
}

import { isNullOrUndefined } from '@dinazor/core';
import { DnXmlElement, DnXmlModel, DnXmlRoot } from '../../shared/utils/dn-serialize';
import { YesNoModel } from '../enum/yes-no.model';
import { DetayliBeyanKiymetKalemModel } from './detaylibeyan-kiymet-kalem.model';

/**
 * Created by cabbar on 23.05.2017.
 */
export class DetayliBeyanKiymetModel {

  @DnXmlElement('TeslimSekli')
  teslimSekli: string;

  @DnXmlElement('FaturaTarihiSayisi')
  faturaTarihiSayisi: string;

  @DnXmlElement('SozlesmeTarihiSayisi')
  sozlesmeTarihiSayisi: string;

  @DnXmlElement('GumrukIdaresiKarari')
  gumrukIdaresiKarari: string;

  @DnXmlModel('otherName', 'AliciSatici')
  aliciSatici: YesNoModel;

  @DnXmlModel('name', 'Munasebet')
  munasebet: YesNoModel;

  @DnXmlModel('name', 'Emsal')
  emsal: YesNoModel;

  @DnXmlElement('AliciSaticiAyrintilar')
  aliciSaticiAyrintilar: string;

  @DnXmlModel('name', 'Kisitlamalar')
  kisitlamalar: YesNoModel;

  @DnXmlModel('name', 'Edim')
  edim: YesNoModel;

  @DnXmlElement('KisitlamalarAyrintilar')
  kisitlamalarAyrintilar: string;

  @DnXmlModel('name', 'Royalti')
  royalti: YesNoModel;

  @DnXmlElement('RoyaltiKosullar')
  royaltiKosullar: string;

  @DnXmlModel('name', 'SaticiyaIntikal')
  saticiyaIntikal: YesNoModel;

  @DnXmlElement('SaticiyaIntikalKosullar')
  saticiyaIntikalKosullar: string;

  @DnXmlElement('SehirYer')
  sehirYer: string;

  @DnXmlElement('Taahutname')
  taahutname: string;

  @DnXmlElement('KiymetKalemler')
  @DnXmlRoot('KiymetKalem')
  detayliBeyanKiymetKalemList: DetayliBeyanKiymetKalemModel[];


  constructor(options: {} = {}) {
    this.teslimSekli = options['teslimSekli'];
    this.faturaTarihiSayisi = options['faturaTarihiSayisi'];
    this.sozlesmeTarihiSayisi = options['sozlesmeTarihiSayisi'];
    this.gumrukIdaresiKarari = options['gumrukIdaresiKarari'];
    this.aliciSatici = isNullOrUndefined(options['aliciSatici']) ? undefined : new YesNoModel(options['aliciSatici']);
    this.munasebet = isNullOrUndefined(options['munasebet']) ? undefined : new YesNoModel(options['munasebet']);
    this.emsal = isNullOrUndefined(options['emsal']) ? undefined : new YesNoModel(options['emsal']);
    this.aliciSaticiAyrintilar = options['aliciSaticiAyrintilar'];
    this.kisitlamalar = isNullOrUndefined(options['kisitlamalar']) ? undefined : new YesNoModel(options['kisitlamalar']);

    this.edim = options['edim'];
    this.kisitlamalarAyrintilar = options['kisitlamalarAyrintilar'];
    this.royalti = options['royalti'];
    this.royaltiKosullar = options['royaltiKosullar'];
    this.saticiyaIntikal = options['saticiyaIntikal'];
    this.saticiyaIntikalKosullar = options['saticiyaIntikalKosullar'];
    this.sehirYer = options['sehirYer'];
    this.taahutname = options['taahutname'];

    if (options['detayliBeyanKiymetKalemList']) {
      this.detayliBeyanKiymetKalemList = Array<DetayliBeyanKiymetKalemModel>();
      options['detayliBeyanKiymetKalemList'].forEach(kiymetKalem => {
        this.detayliBeyanKiymetKalemList.push(new DetayliBeyanKiymetKalemModel(kiymetKalem));
      });
    }

  }
}

import { DnXmlElement, DnXmlModel, DnXmlRoot } from '../../shared/utils/dn-serialize';
import { DetayliBeyanOzetBeyanAcmaModel } from './detaylibeyan-ozetbeyan-acma.model';
import { DetayliBeyanTasimaSenetModel } from './detaylibeyan-tasimasenet.model';
import { YesNoModel } from '../enum/yes-no.model';
import { OzetBeyanAcmaSekliModel } from '../enum/ozetbeyan-acma-sekli-model';
import { isNullOrUndefined } from '@dinazor/core';

/**
 * Created by cabbar on 23.05.2017.
 */
export class DetayliBeyanOzetBeyanModel {

  @DnXmlElement('Ozetbeyan_no')
  ozetBeyanNo: string;

  @DnXmlElement('Ozetbeyan_islem_kapsami')
  ozetBeyanIslemKapsami: string;

  @DnXmlModel('name', 'Ambar_ici')
  isAmbarIci: YesNoModel;

  @DnXmlModel('name', 'Baska_rejim')
  isBaskaRejim: YesNoModel;

  @DnXmlElement('Aciklama')
  aciklama: string;

  @DnXmlElement('ozbyacma_bilgi')
  @DnXmlRoot('tasimasenetleri')
  detayliBeyanTasimaSenetList: DetayliBeyanTasimaSenetModel[];


  constructor(options: {} = {}) {
    this.ozetBeyanNo = options['ozetBeyanNo'];
    this.ozetBeyanIslemKapsami =options['ozetBeyanIslemKapsami'];
    this.isAmbarIci = isNullOrUndefined(options['isAmbarIci']) ? undefined : new YesNoModel(options['isAmbarIci']);
    this.isBaskaRejim = isNullOrUndefined(options['isBaskaRejim']) ? undefined : new YesNoModel(options['isBaskaRejim']);
    this.aciklama = options['aciklama'];

    if (options['detayliBeyanTasimaSenetList']) {
      this.detayliBeyanTasimaSenetList = Array<DetayliBeyanTasimaSenetModel>();
      options['detayliBeyanTasimaSenetList'].forEach(senetAcma => {
        this.detayliBeyanTasimaSenetList.push(new DetayliBeyanTasimaSenetModel(senetAcma));
      });
    }
  }

}

import { isNullOrUndefined } from '@dinazor/core';
import { DnXmlElement, DnXmlIgnore, DnXmlModel } from '../../shared/utils/dn-serialize';
import {ModelBase} from "../model";
/**
 * Created by cabbar on 23.05.2017.
 */
export class DetayliBeyanSoruModel extends ModelBase{

  @DnXmlElement('Soru_no')
  kod: string;

  @DnXmlIgnore()
  aciklama: string;

  @DnXmlElement('Kalem_no')
  kalemNo: string;

  @DnXmlElement( 'Cevap')
  cevap: string;

  // @DnXmlIgnore()
  // soruTip: SoruModel;


  constructor(options: {} = {}) {
    super();
    this.equalizer(options);
  }

}

import {isNullOrUndefined} from '@dinazor/core';
import {DnXmlElement, DnXmlModel} from '../../shared/utils/dn-serialize';
import {SimpleDetaylibeyanKalemModel} from '../simple/simple-detaylibeyan-kalem.model';
import {VergiOdemeSekliModel} from '../enum/vergi-odemesekli.model';
import {ModelBase} from "../model";

/**
 * Created by cabbar on 23.05.2017.
 */
export class DetayliBeyanVergiModel extends ModelBase {

  @DnXmlModel('kalemNo', 'Kalem_no')
  simpleDetayliBeyanKalem: SimpleDetaylibeyanKalemModel;

  @DnXmlElement('Kod')
  kod: string;

  @DnXmlElement('Aciklama')
  aciklama: string;

  @DnXmlElement('Miktar')
  miktar: number;

  @DnXmlElement('Oran')
  oran: string;

  @DnXmlElement('Odeme_sekli')
  vergiOdemeSekil: string;

  @DnXmlElement('Vergi_matrahi')
  vergiMatrahi: number;

  constructor(options: {} = {}) {
    super();
    this.simpleDetayliBeyanKalem = isNullOrUndefined(options['simpleDetayliBeyanKalem']) ? undefined : new SimpleDetaylibeyanKalemModel(options['simpleDetayliBeyanKalem']);
    this.equalizer(options)


  }

}

export class GtbUserModel {

  idUser: number;
  bilgeKullaniciAdi: string;
  bilgeSifre: string;
  servisKullaniciAdi: string;
  servisSifre: string;
  eImzaPin: string;
  name: string;
  surname: string;
  username: string;
  mail: string;
  password: string;
  id: number;

  constructor(options: {} = {}) {
  }
}

import {DnXmlElement, DnXmlModel, DnXmlRoot} from '../../shared/utils/dn-serialize';
import {OzetbeyanTasimaSenetModel} from './ozetbeyan-tasimasenet.model';
import {isNullOrUndefined} from '@dinazor/core';
import {FirmaModel} from "../enum/firma.model";
import {ModelBase} from "../model";

export class OzetBeyanBilgiModel extends ModelBase {

  @DnXmlElement('RefNo')
  refNo: string;
  @DnXmlElement('BeyanTuru')
  beyanTuru: string;
  @DnXmlElement('Rejim')
  rejim: string;
  @DnXmlElement('TasimaSekli')
  tasimaSekli: string;
  @DnXmlElement('GumrukIdaresi')
  gumrukIdaresi: string;
  @DnXmlElement('EkBelgeSayisi')
  ekBelgeSayisi: number;
  @DnXmlElement('KullaniciKodu')
  kullaniciKodu: string;
  @DnXmlModel('vergiNo', 'BeyanSahibiVergiNo')
  beyanSahibi: FirmaModel;
  @DnXmlElement('TasiyiciVergiNo')
  tasiyiciFirmaVergiNo: string;
  @DnXmlElement('TasitinAdi')
  tasitAdi: string;
  @DnXmlElement('PlakaSeferNo')
  tasitNumarasi: string;
  @DnXmlElement('ReferansNumarasi')
  tasitReferansNumarasi: string;
  @DnXmlElement('UlkeKodu')
  tasitUlkesi: string;
  @DnXmlElement('VarisTarihSaati')
  tasitVarisTarihTescil: string;
  @DnXmlElement('OncekiBeyanNo')
  oncekiBeyanNo: string;
  @DnXmlElement('GrupTasimaSenediNo')
  grupTasimaSenediNo: string;
  @DnXmlElement('VarisCikisGumrukIdaresi')
  ilkVarisYeri: string;
  @DnXmlElement('TirAtaKarneNo')
  tirKarneNo: string;
  @DnXmlElement('Kurye')
  isKurye: boolean;
  @DnXmlElement('DorseNo1')
  tasitDorseNo1: string;
  @DnXmlElement('DorseNo1Uyrugu')
  tasitDorse1Uyruk: string;
  @DnXmlElement('DorseNo2')
  tasitDorseNo2: string;
  @DnXmlElement('DorseNo2Uyrugu')
  tasitDorse2Uyruk: string;
  @DnXmlElement('Diger')
  diger: string;
  @DnXmlElement('XmlRefId')
  xmlRefId: string;
  @DnXmlElement('UlkeKoduYuk')
  yuklemeUlkesi: string;
  @DnXmlElement('LimanYerAdiYuk')
  yuklemeLimani: string;
  @DnXmlElement('UlkeKoduBos')
  bosaltmaUlkesi: string;
  @DnXmlElement('LimanYerAdiBos')
  bosaltmaLimani: string;
  @DnXmlElement('YuklemeBosaltmaYeri')
  yuklemeBosaltmaYeri: string;
  @DnXmlElement('TasiyiciFirma')
  tasiyiciFirma: FirmaModel;
  @DnXmlElement('EmniyetGuvenlik')
  isEmniyetGuvenlik: boolean;

  // @DnXmlElement('TasitinUgradigiUlkeler')
  // @DnXmlRoot('TasitinUgradigiUlkeBilgisi')
  // tasitinUgradigiUlkelerList: OzetbeyanTasitinUgradigiUlke[];

  @DnXmlElement('TasimaSenetleri')
  @DnXmlRoot('TasimaSenediBilgisi')
  tasimaSenetList: OzetbeyanTasimaSenetModel[];

  // @DnXmlElement('OzbyAcmalar')
  // @DnXmlRoot('ArrayOfOzbyAcmaBilgisi')
  // tasimaSenetList: OzbyAcmaModel[];


  constructor(options: {} = {}) {
    super();
    this.equalizer(options);

    this.beyanSahibi = isNullOrUndefined(options['beyanSahibi']) ? undefined : new FirmaModel(options['beyanSahibi']);


    if (options['tasimaSenetList']) {
      this.tasimaSenetList = Array<OzetbeyanTasimaSenetModel>();
      options['tasimaSenetList'].forEach(senet => {
        this.tasimaSenetList.push(new OzetbeyanTasimaSenetModel(senet));
      });
    }

    if (!isNullOrUndefined(options['tasiyiciFirma']) && isNullOrUndefined(options['tasiyiciFirma']['vergiNo'])) {
      this.tasiyiciFirma = new FirmaModel(options['tasiyiciFirma']);
    } else if (!isNullOrUndefined(options['tasiyiciFirma']) && !isNullOrUndefined(options['tasiyiciFirma']['vergiNo'])) {
      this.tasiyiciFirmaVergiNo = options['tasiyiciFirma']['vergiNo'];
    }

    // if (options['tasitinUgradigiUlkelerList']) {
    //   this.tasitinUgradigiUlkelerList = Array<TasitinUgradigiUlke>();
    //   options['tasitinUgradigiUlkelerList'].forEach(senet => {
    //     this.tasitinUgradigiUlkelerList.push(new TasitinUgradigiUlke(senet));
    //   });
    // }

  }


}

import {DnXmlElement} from '../../shared/utils/dn-serialize';
import {isNullOrUndefined} from '@dinazor/core';
import {ModelBase} from "../model";

export class OzetbeyanEsyaSatirModel extends ModelBase {

  @DnXmlElement('BmEsyaKodu')//BmEsyaKodu
  bmEsyaKodu: string;
  @DnXmlElement('BrutAgirlik')//BrutAgirlik
  brutAgirlik: number;
  @DnXmlElement('EsyaKodu')//EsyaKodu
  gtipNo: string;
  @DnXmlElement('EsyaninTanimi')//EsyaninTanimi
  esyaTanim: string;
  @DnXmlElement('KalemFiyati')//KalemFiyati
  kalemFiyat: number;
  @DnXmlElement('KalemFiyatiDoviz') //KalemFiyatiDoviz
  kalemFiyatDoviz: string;
  @DnXmlElement('KalemSiraNo')//KalemSiraNo
  kalemSiraNo: number;
  @DnXmlElement('NetAgirlik')//NetAgirlik
  netAgirlik: number;
  @DnXmlElement('OlcuBirimi') //OlcuBirimi
  olcuBirim: string;


  constructor(options: {}
                = {}) {
    super();
    this.equalizer(options);
  }
}

import {DnXmlElement, DnXmlModel, DnXmlRoot} from '../../shared/utils/dn-serialize';
import {OzetbeyanEsyaSatirModel} from './ozetbeyan-esya-satir.model';
import {ModelBase} from "../model";

export class OzetbeyanTasimaSatirModel extends ModelBase {

  @DnXmlElement('BrutAgirlik')//BrutAgirlik
  brutAgirlik: number;

  @DnXmlElement('KapAdedi')//KapAdedi
  kapAdet: number;

  @DnXmlElement('KapCinsi') //KapCinsi
  kapKod: string;

  @DnXmlElement('KonteynerTipi')//KontynerTipi
  konteynerTip: string;

  @DnXmlElement('MarkaNo')//MarkaNo
  markaNo: string;

  @DnXmlElement('MuhurNumarasi')//MuhurNumarasi
  muhurNo: string;

  @DnXmlElement('NetAgirlik')//NetAgirlik
  netAgirlik: number;

  @DnXmlElement('OlcuBirimi')//OlcuBirimi
  olcuBirim: string;

  @DnXmlElement('SatirNo')//SatirNo
  satirNo: number;

  @DnXmlElement('EsyaBilgileri')
  @DnXmlRoot('EsyaBilgisi')
  esyaSatirList: OzetbeyanEsyaSatirModel[];

  constructor(options: {}
                = {}) {
    super();
    this.equalizer(options);
    if (options['esyaSatirList']) {
      this.esyaSatirList = Array<OzetbeyanEsyaSatirModel>();
      options['esyaSatirList'].forEach(satir => {
        this.esyaSatirList.push(new OzetbeyanEsyaSatirModel(satir));
      });
    }
  }
}

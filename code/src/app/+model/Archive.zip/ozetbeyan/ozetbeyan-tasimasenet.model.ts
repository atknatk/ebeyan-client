import {isNullOrUndefined} from '@dinazor/core';
import {DnXmlElement, DnXmlModel, DnXmlRoot} from '../../shared/utils/dn-serialize';
import {OzetbeyanIhracatModel} from './ozetbeyan-ihracat.model';
import {OzetbeyanTasimaSatirModel} from './ozetbeyan-tasima-satir.model';
import {OzetbeyanUgranilanUlkelerModel} from './ozetbeyan-ugranilan-ulkeler.model';
import {FirmaModel} from "../enum/firma.model";
import {OdemeSekliModel} from "../enum/odemesekli.model";
import {ModelBase} from "../model";

export class OzetbeyanTasimaSenetModel extends ModelBase {

  @DnXmlElement('TasimaSenediNo')//TasimaSenediNo
  tasimaSenetNo: string;

  @DnXmlElement('DuzenlendigiUlke')
  düzenlendigiUlke: string;

  @DnXmlElement('FaturaToplami')//FaturaToplami
  faturaToplam: number;

  @DnXmlElement('FaturaDoviz') //FaturaDoviz
  faturaToplamDoviz: string;

  @DnXmlElement('NavlunTutari')//NavlunTutari
  navlunTutar: string;

  @DnXmlElement('NavlunDoviz') //NavlunDoviz
  navlunTutarDoviz: string;

  @DnXmlModel('adiUnvani', 'GondericiAdi')
  @DnXmlModel('vergiNo', 'GondericiVergiNo') //GondericiAdi , GondericiVergiNo
  gonderici: FirmaModel;

  @DnXmlModel('adiUnvani', 'AliciAdi')
  @DnXmlModel('vergiNo', 'AliciVergiNo') //GondericiAdi , GondericiVergiNo
  alici: FirmaModel;

  @DnXmlModel('adiUnvani', 'BildirimTarafiAdi')
  @DnXmlModel('vergiNo', 'BildirimTarafiVergiNo') //GondericiAdi , GondericiVergiNo
  bildirimTarafi: FirmaModel;

  //@DnXmlModel('adiUnvani', 'GondericiAdi')
  @DnXmlModel('vergiNo', 'AcentaVergiNo') //GondericiAdi , GondericiVergiNo
  acenta: FirmaModel;

  @DnXmlModel('id', 'OdemeSekli') //OdemeSekli
  odemeSekil: OdemeSekliModel;

  @DnXmlElement('EsyaninBulunduguYer')//EsyaninBulunduguYer
  esyaninBulunduguYer: string;

  @DnXmlElement('GrupMu')//GrupMu
  isGrup: boolean;

  @DnXmlElement('AmbarHariciMi')
  isAmbarHarici: boolean;

  @DnXmlElement('KonteynerMi')//KonteynerMi
  isKonteyner: boolean;

  @DnXmlElement('OncekiSeferNumarasi')//OncekiSeferNumarasi
  oncekiSeferinNumarasi: string;

  @DnXmlElement('OncekiSeferTarihi')//OncekiSeferTarihi
  oncekiSeferinTarihi: Date;

  @DnXmlElement('OzetBeyanNo')
  ozetBeyanNo: any; // TODO bu ne olacak

  @DnXmlElement('RoroMu')
  isRoro: boolean;

  @DnXmlElement('SenetSiraNo')//SenetSiraNo
  senetSiraNo: string;

  @DnXmlElement('EmniyetGuvenlikT')
  isEmniyetGuvenlik: boolean;

  @DnXmlElement('AktarmaYapilacakMi')//AktarmaYapilacakMi
  isAktarma: boolean;

  @DnXmlElement('TasimaSatirlari')
  @DnXmlRoot('TasimaSatiriBilgisi')
  tasimaSatirList: OzetbeyanTasimaSatirModel[];

  @DnXmlElement('UgranilanUlkeler')
  @DnXmlRoot('UgranilanUlkeBilgisi')
  ugranilanUlkelerList: OzetbeyanUgranilanUlkelerModel[];

  @DnXmlElement('Ihracatlar')
  @DnXmlRoot('IhracatBilgisi')
  ihracatIlgiliBeyanList: OzetbeyanIhracatModel[];


  constructor(options: {}
                = {}) {
    super();
    this.equalizer(options);
    this.acenta = isNullOrUndefined(options['acenta']) ? undefined : new FirmaModel(options['acenta']);
    this.alici = isNullOrUndefined(options['alici']) ? undefined : new FirmaModel(options['alici']);
    this.bildirimTarafi = isNullOrUndefined(options['bildirimTarafi']) ? undefined : new FirmaModel(options['bildirimTarafi']);
    this.gonderici = isNullOrUndefined(options['gonderici']) ? undefined : new FirmaModel(options['gonderici']);
    this.odemeSekil = isNullOrUndefined(options['odemeSekil']) ? undefined : new OdemeSekliModel(options['odemeSekil']);

    if (options['tasimaSatirList']) {
      this.tasimaSatirList = Array<OzetbeyanTasimaSatirModel>();
      options['tasimaSatirList'].forEach(satir => {
        this.tasimaSatirList.push(new OzetbeyanTasimaSatirModel(satir));
      });
    }

    if (options['ugranilanUlkelerList']) {
      this.ugranilanUlkelerList = Array<OzetbeyanUgranilanUlkelerModel>();
      options['ugranilanUlkelerList'].forEach(ulke => {
        this.ugranilanUlkelerList.push(new OzetbeyanUgranilanUlkelerModel(ulke));
      });
    }

    if (options['ihracatIlgiliBeyanList']) {
      this.ihracatIlgiliBeyanList = Array<OzetbeyanIhracatModel>();
      options['ihracatIlgiliBeyanList'].forEach(ulke => {
        this.ihracatIlgiliBeyanList.push(new OzetbeyanIhracatModel(ulke));
      });
    }
  }
}

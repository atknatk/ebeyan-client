import {DnXmlElement} from "../../shared/utils/dn-serialize";
import {ModelBase} from "../model";

export class OzetbeyanUgranilanUlkelerModel extends ModelBase {


  @DnXmlElement('LimanYerAdi')
  limanKod: string;
  @DnXmlElement('UlkeKodu')
  ulkeKod: string;


  constructor(options: {}
                = {}) {
    super();
    this.equalizer(options);
  }
}

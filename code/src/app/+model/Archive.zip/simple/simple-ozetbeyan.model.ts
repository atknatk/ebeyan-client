/**
 * Created by cabbar on 23.05.2017.
 */
export class SimpleOzetBeyanModel {

  tescilNo: string;

  constructor(options: {} = {}) {
    this.tescilNo = options['tescilNo'];
  }
}

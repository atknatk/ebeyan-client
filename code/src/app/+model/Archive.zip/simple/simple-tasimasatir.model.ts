/**
 * Created by cabbar on 23.05.2017.
 */
export class SimpleTasimaSatirModel {

  tasimaSatirNo: string;

  constructor(options: {} = {}) {
    this.tasimaSatirNo = options['tasimaSatirNo'];
  }
}

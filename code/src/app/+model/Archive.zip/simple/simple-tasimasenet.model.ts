/**
 * Created by cabbar on 23.05.2017.
 */
export class SimpleTasimaSenetModel {

  tasimaSenetNo: string;


  constructor(options: {} = {}) {
    this.tasimaSenetNo = options['tasimaSenetNo'];
  }
}

import {VarisbildirimiTasitinUgradigiUlke} from './varisbildirimi-tasitin-ugradigi-ulke';
import {DnXmlElement, DnXmlModel, DnXmlRoot} from '../../shared/utils/dn-serialize';
import {VarisbildirimiTasimaSenetModel} from './varisbildirimi-tasimasenet.model';
import {isNullOrUndefined} from '@dinazor/core';
import {FirmaModel} from "../enum/firma.model";
import {ModelBase} from "../model";

export class VarisbildirimiBilgiModel extends ModelBase {

  @DnXmlElement('RefNo')
  refNo: string;
  @DnXmlElement('BeyanTuru')
  beyanTuru: string;
  @DnXmlElement('Rejim')
  rejim: string;
  @DnXmlElement('TasimaSekli')
  tasimaSekli: string;
  @DnXmlElement('GumrukIdaresi')
  gumrukIdaresi: string;
  @DnXmlElement('EkBelgeSayisi')
  ekBelgeSayisi: number;
  @DnXmlElement('KullaniciKodu')
  kullaniciKodu: string;
  @DnXmlModel('vergiNo', 'BeyanSahibiVergiNo')
  beyanSahibi: FirmaModel;
  @DnXmlElement('TasiyiciVergiNo')
  tasiyiciFirmaVergiNo: string;
  @DnXmlElement('TasitinAdi')
  tasitAdi: string;
  @DnXmlElement('PlakaSeferNo')
  tasitNumarasi: string;
  @DnXmlElement('ReferansNumarasi')
  tasitReferansNumarasi: string;
  @DnXmlElement('UlkeKodu')
  tasitUlkesi: string;
  @DnXmlElement('VarisTarihSaati')
  tasitVarisTarihTescil: string;
  @DnXmlElement('OncekiBeyanNo')
  oncekiBeyanNo: string;
  @DnXmlElement('GrupTasimaSenediNo')
  grupTasimaSenediNo: string;
  @DnXmlElement('VarisCikisGumrukIdaresi')
  ilkVarisYeri: string;
  @DnXmlElement('TirAtaKarneNo')
  tirKarneNo: string;
  @DnXmlElement('Kurye')
  isKurye: boolean;
  @DnXmlElement('DorseNo1')
  tasitDorseNo1: string;
  @DnXmlElement('DorseNo1Uyrugu')
  tasitDorse1Uyruk: string;
  @DnXmlElement('DorseNo2')
  tasitDorseNo2: string;
  @DnXmlElement('DorseNo2Uyrugu')
  tasitDorse2Uyruk: string;
  @DnXmlElement('Diger')
  diger: string;
  @DnXmlElement('XmlRefId')
  xmlRefId: string;
  @DnXmlElement('UlkeKoduYuk')
  yuklemeUlkesi: string;
  @DnXmlElement('LimanYerAdiYuk')
  yuklemeLimani: string;
  @DnXmlElement('UlkeKoduBos')
  bosaltmaUlkesi: string;
  @DnXmlElement('LimanYerAdiBos')
  bosaltmaLimani: string;
  @DnXmlElement('YuklemeBosaltmaYeri')
  yuklemeBosaltmaYeri: string;
  @DnXmlElement('TasiyiciFirma')
  tasiyiciFirma: FirmaModel;
  @DnXmlElement('EmniyetGuvenlik')
  isEmniyetGuvenlik: boolean;

  @DnXmlElement('TasitinUgradigiUlkeler')
  @DnXmlRoot('TasitinUgradigiUlkeBilgisi')
  varisBildirimiTasitinUgradigiUlkelerList: VarisbildirimiTasitinUgradigiUlke[];

  @DnXmlElement('TasimaSenetleri')
  @DnXmlRoot('TasimaSenediBilgisi')
  varisBildirimiTasimaSenetList: VarisbildirimiTasimaSenetModel[];


  constructor(options: {} = {}) {
    super();
    this.equalizer(options);
    this.beyanSahibi = isNullOrUndefined(options['beyanSahibi']) ? undefined : new FirmaModel(options['beyanSahibi']);


    if (isNullOrUndefined(options['tasitVarisTarihTescil'])) {
      this.tasitVarisTarihTescil = '0001-01-01T00:00:00';
    }

    if (!isNullOrUndefined(options['tasiyiciFirma'])) {
      if (isNullOrUndefined(options['tasiyiciFirma']['vergiNo'])) {
        this.tasiyiciFirma = isNullOrUndefined(options['tasiyiciFirma']) ? undefined : new FirmaModel(options['tasiyiciFirma']);
      } else {
        this.tasiyiciFirmaVergiNo = options['tasiyiciFirma']['vergiNo'];
      }
    }

    if (options['varisBildirimiTasimaSenetList']) {
      this.varisBildirimiTasimaSenetList = Array<VarisbildirimiTasimaSenetModel>();
      options['varisBildirimiTasimaSenetList'].forEach(senet => {
        this.varisBildirimiTasimaSenetList.push(new VarisbildirimiTasimaSenetModel(senet));
      });
    }
    if (options['varisBildirimiTasitinUgradigiUlkelerList']) {
      this.varisBildirimiTasitinUgradigiUlkelerList = Array<VarisbildirimiTasitinUgradigiUlke>();
      options['varisBildirimiTasitinUgradigiUlkelerList'].forEach(senet => {
        this.varisBildirimiTasitinUgradigiUlkelerList.push(new VarisbildirimiTasitinUgradigiUlke(senet));
      });
    }
  }


}

import {DnXmlElement} from '../../shared/utils/dn-serialize';
import {ModelBase} from "../model";

export class VarisbildirimiIhracatModel extends ModelBase {


  @DnXmlElement('BrutAgirlik')
  brutAgirlik: number;

  @DnXmlElement('KapAdedi')
  kapAdet: number;

  @DnXmlElement('Numarasi')
  numarasi: string;

  @DnXmlElement('ParcaliMi')
  isParcali: boolean;

  @DnXmlElement('Tipi')
  ihracatIlgiliBeyanTip: string;


  constructor(options: {}
                = {}) {
    super();
    this.equalizer(options);
  }
}

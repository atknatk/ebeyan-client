import {DnXmlElement, DnXmlModel, DnXmlRoot} from '../../shared/utils/dn-serialize';
import {isNullOrUndefined} from '@dinazor/core';
import {VarisbildirimiTasimaSatirModel} from './varisbildirimi-tasima-satir.model';
import {VarisbildirimiIhracatModel} from './varisbildirimi-ihracat.model';
import {SimpleOzetBeyanModel} from '../simple/simple-ozetbeyan.model';
import {ModelBase} from "../model";
import {FirmaModel} from "../enum/firma.model";
import {OdemeSekliModel} from "../enum/odemesekli.model";

export class VarisbildirimiTasimaSenetModel extends ModelBase {

  @DnXmlElement('TasimaSenediNo')//  TasimaSenediNo
  tasimaSenetNo: string;

  @DnXmlElement('DuzenlendigiUlke')
  düzenlendigiUlke: string;

  @DnXmlElement('FaturaToplami')//  FaturaToplami
  faturaToplam: number;

  @DnXmlElement('FaturaDoviz') //  FaturaDoviz
  faturaToplamDoviz: string;

  @DnXmlElement('NavlunTutari')//  NavlunTutari
  navlunTutar: number;

  @DnXmlElement('NavlunDoviz') //  NavlunDoviz
  navlunTutarDoviz: string;

  @DnXmlModel('adiUnvani', 'GondericiAdi')
  @DnXmlModel('vergiNo', 'GondericiVergiNo') //  GondericiAdi , GondericiVergiNo
  gonderici: FirmaModel;

  @DnXmlModel('adiUnvani', 'AliciAdi')
  @DnXmlModel('vergiNo', 'AliciVergiNo') // GondericiAdi , GondericiVergiNo
  alici: FirmaModel;

  @DnXmlModel('adiUnvani', 'BildirimTarafiAdi')
  @DnXmlModel('vergiNo', 'BildirimTarafiVergiNo') // GondericiAdi , GondericiVergiNo
  bildirimTarafi: FirmaModel;

  // @DnXmlModel('adiUnvani', 'GondericiAdi')
  @DnXmlModel('vergiNo', 'AcentaVergiNo') // GondericiAdi , GondericiVergiNo
  acenta: FirmaModel;

  @DnXmlModel('id', 'OdemeSekli') // OdemeSekli
  odemeSekil: OdemeSekliModel;

  @DnXmlElement('EsyaninBulunduguYer')// EsyaninBulunduguYer
  esyaninBulunduguYer: string;

  @DnXmlElement('GrupMu')// GrupMu
  isGrup: boolean;

  @DnXmlElement('AmbarHariciMi')
  isAmbarHarici: boolean;

  @DnXmlElement('KonteynerMi')// KonteynerMi
  isKonteyner: boolean;

  @DnXmlElement('OncekiSeferNumarasi')// OncekiSeferNumarasi
  oncekiSeferinNumarasi: string;

  @DnXmlElement('OncekiSeferTarihi')// OncekiSeferTarihi
  oncekiSeferinTarihi: Date;

  @DnXmlModel('tescilNo', 'OzetBeyanNo')
  simpleOzetBeyan: SimpleOzetBeyanModel;

  @DnXmlElement('RoroMu')
  isRoro: boolean;

  @DnXmlElement('SenetSiraNo')// SenetSiraNo
  senetSiraNo: string;

  @DnXmlElement('EmniyetGuvenlikT')
  isEmniyetGuvenlik: boolean;

  @DnXmlElement('AktarmaYapilacakMi')// AktarmaYapilacakMi
  isAktarma: boolean;

  @DnXmlElement('TasimaSatirlari')
  @DnXmlRoot('TasimaSatiriBilgisi')
  varisBildirimiTasimaSatirList: VarisbildirimiTasimaSatirModel[];

  @DnXmlElement('Ihracatlar')
  @DnXmlRoot('IhracatBilgisi')
  ihracatIlgiliBeyanList: VarisbildirimiIhracatModel[];


  constructor(options: {}
                = {}) {
    super();
    this.equalizer(options);

    this.acenta = isNullOrUndefined(options['acenta']) ? undefined : new FirmaModel(options['acenta']);
    this.alici = isNullOrUndefined(options['alici']) ? undefined : new FirmaModel(options['alici']);
    this.gonderici = isNullOrUndefined(options['gonderici']) ? undefined : new FirmaModel(options['gonderici']);
    this.simpleOzetBeyan = isNullOrUndefined(options['simpleOzetBeyan']) ? undefined : new SimpleOzetBeyanModel(options['simpleOzetBeyan']);
    this.odemeSekil = isNullOrUndefined(options['odemeSekil']) ? undefined : new OdemeSekliModel(options['odemeSekil']);
    this.bildirimTarafi = isNullOrUndefined(options['bildirimTarafi']) ? undefined : new FirmaModel(options['bildirimTarafi']);

    if (options['varisBildirimiTasimaSatirList']) {
      this.varisBildirimiTasimaSatirList = Array<VarisbildirimiTasimaSatirModel>();
      options['varisBildirimiTasimaSatirList'].forEach(satir => {
        this.varisBildirimiTasimaSatirList.push(new VarisbildirimiTasimaSatirModel(satir));
      });
    }

    if (options['ihracatIlgiliBeyanList']) {
      this.ihracatIlgiliBeyanList = Array<VarisbildirimiIhracatModel>();
      options['ihracatIlgiliBeyanList'].forEach(ulke => {
        this.ihracatIlgiliBeyanList.push(new VarisbildirimiIhracatModel(ulke));
      });
    }

  }
}

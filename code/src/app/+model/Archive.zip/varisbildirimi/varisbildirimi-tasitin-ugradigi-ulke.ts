import {DnXmlElement} from '../../shared/utils/dn-serialize';
import {ModelBase} from "../model";

export class VarisbildirimiTasitinUgradigiUlke extends ModelBase {


  @DnXmlElement('LimanYerAdi')
  limanKod: string;
  @DnXmlElement('UlkeKodu')
  ulkeKod: string;
  @DnXmlElement('HareketTarihSaati')
  hareketTarihTescil: string;


  constructor(options: {}
                = {}) {
    super();
    this.equalizer(options);
  }
}
